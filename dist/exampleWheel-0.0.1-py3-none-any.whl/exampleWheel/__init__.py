def init_welcome_message(message):
    print(f"This is an example wheel package : [__init__.py]init function : message --> {message}")