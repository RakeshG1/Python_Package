from exampleWheel.__init__ import *

def example_message_1(message):
    init_welcome_message(message)

def example_message(message):
    print("This is an example wheel package : [example.py]example function : message --> %s " %(message))